package bean;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VendedorTest {

    @Test
    public void testConstructor() {
        Vendedor vendedor = new Vendedor(1, "Juan", "Perez", "Gomez", 30, "555-1234", "M");
        
        assertEquals(1, vendedor.getCodigoVendedor());
        assertEquals("Juan", vendedor.getNombreVendedor());
        assertEquals("Perez", vendedor.getApePatVendedor());
        assertEquals("Gomez", vendedor.getApeMatVendedor());
        assertEquals(30, vendedor.getEdad());
        assertEquals("555-1234", vendedor.getTelefono());
        assertEquals("M", vendedor.getSexo());
    }

    @Test
    public void testSettersAndGetters() {
        Vendedor vendedor = new Vendedor(0, "", "", "", 0, "", "");

        vendedor.setCodigoVendedor(2);
        vendedor.setNombreVendedor("Maria");
        vendedor.setApePatVendedor("Lopez");
        vendedor.setApeMatVendedor("Martinez");
        vendedor.setEdad(25);
        vendedor.setTelefono("555-5678");
        vendedor.setSexo("F");

        assertEquals(2, vendedor.getCodigoVendedor());
        assertEquals("Maria", vendedor.getNombreVendedor());
        assertEquals("Lopez", vendedor.getApePatVendedor());
        assertEquals("Martinez", vendedor.getApeMatVendedor());
        assertEquals(25, vendedor.getEdad());
        assertEquals("555-5678", vendedor.getTelefono());
        assertEquals("F", vendedor.getSexo());
    }
}
