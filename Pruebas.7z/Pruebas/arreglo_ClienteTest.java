package modelo;

import bean.Cliente;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class arreglo_ClienteTest {

    @Test
    public void testAdicionarCliente() {
        arreglo_Cliente arregloCliente = new arreglo_Cliente();
        Cliente cliente = new Cliente(1, "Pedro", "Lopez", "Garcia", 30, 12345678, 987654321, "Av. Siempre Viva 123", "B12345");

        String mensaje = arregloCliente.adicionar(cliente);
        assertEquals("El cliente se guardo correctamente", mensaje);

        String mensajeDuplicado = arregloCliente.adicionar(cliente);
        assertEquals("El cliente ya existe", mensajeDuplicado);
    }

    @Test
    public void testBuscarCliente() {
        arreglo_Cliente arregloCliente = new arreglo_Cliente();
        Cliente cliente = new Cliente(2, "Ana", "Martinez", "Fernandez", 25, 87654321, 123456789, "Calle Falsa 456", "C67890");
        arregloCliente.adicionar(cliente);

        Cliente encontrado = arregloCliente.buscar(2);
        assertNotNull(encontrado);
        assertEquals("Ana", encontrado.getNombre());
    }

    @Test
    public void testEliminarCliente() {
        arreglo_Cliente arregloCliente = new arreglo_Cliente();
        Cliente cliente = new Cliente(3, "Luis", "Garcia", "Ramirez", 40, 45678912, 987654321, "Av. Los Rosales 789", "L34567");
        arregloCliente.adicionar(cliente);

        arregloCliente.eliminar(cliente);
        assertNull(arregloCliente.buscar(3));
    }

    @Test
    public void testActualizarCliente() {
        arreglo_Cliente arregloCliente = new arreglo_Cliente();
        Cliente cliente = new Cliente(4, "Mario", "Fernandez", "Santos", 35, 78965412, 456789123, "Calle Principal 321", "M56789");
        arregloCliente.adicionar(cliente);

        Cliente clienteActualizado = new Cliente(4, "Mario", "Fernandez", "Lopez", 36, 78965412, 456789123, "Calle Nueva 123", "M56789");
        arregloCliente.actualizar(clienteActualizado);

        Cliente encontrado = arregloCliente.buscar(4);
        assertNotNull(encontrado);
        assertEquals("Lopez", encontrado.getApeMaterno());
        assertEquals("Calle Nueva 123", encontrado.getDireccion());
    }

    @Test
    public void testTotalCliente() {
        arreglo_Cliente arregloCliente = new arreglo_Cliente();
        assertEquals(0, arregloCliente.totalCliente());

        arregloCliente.adicionar(new Cliente(5, "Jose", "Hernandez", "Diaz", 28, 65478912, 789654321, "Av. Las Flores 987", "J67890"));
        assertEquals(1, arregloCliente.totalCliente());
    }
}
