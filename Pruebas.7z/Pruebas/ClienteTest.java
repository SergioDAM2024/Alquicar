package bean;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ClienteTest {

    @Test
    public void testConstructorCompleto() {
        Cliente cliente = new Cliente(1, "Pedro", "Lopez", "Garcia", 30, 12345678, 987654321, "Av. Siempre Viva 123", "B12345");

        assertEquals(1, cliente.getCodigo());
        assertEquals("Pedro", cliente.getNombre());
        assertEquals("Lopez", cliente.getApePaterno());
        assertEquals("Garcia", cliente.getApeMaterno());
        assertEquals(30, cliente.getEdad());
        assertEquals(12345678, cliente.getDni());
        assertEquals(987654321, cliente.getTelefono());
        assertEquals("Av. Siempre Viva 123", cliente.getDireccion());
        assertEquals("B12345", cliente.getLicencia());
    }

    @Test
    public void testSettersAndGetters() {
        Cliente cliente = new Cliente(0, "", "", "", 0, 0, 0, "", "");

        cliente.setCodigo(2);
        cliente.setNombre("Ana");
        cliente.setApePaterno("Martinez");
        cliente.setApeMaterno("Fernandez");
        cliente.setEdad(25);
        cliente.setDni(87654321);
        cliente.setTelefono(123456789);
        cliente.setDireccion("Calle Falsa 456");
        cliente.setLicencia("C67890");

        assertEquals(2, cliente.getCodigo());
        assertEquals("Ana", cliente.getNombre());
        assertEquals("Martinez", cliente.getApePaterno());
        assertEquals("Fernandez", cliente.getApeMaterno());
        assertEquals(25, cliente.getEdad());
        assertEquals(87654321, cliente.getDni());
        assertEquals(123456789, cliente.getTelefono());
        assertEquals("Calle Falsa 456", cliente.getDireccion());
        assertEquals("C67890", cliente.getLicencia());
    }
}
