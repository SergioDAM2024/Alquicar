package modelo;

import bean.Vehiculo;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class ArregloVehiculoTest {

    @Test
    public void testAdicionarVehiculo() {
        ArregloVehiculo arregloVehiculo = new ArregloVehiculo();
        Vehiculo vehiculo = new Vehiculo(1, "Toyota", "Corolla", "ABC-123", "Manual", "Gasolina", 5, "Económico", 50.0, "Disponible", "ruta/img.png");

        String mensaje = arregloVehiculo.adicionar(vehiculo);
        assertEquals("Vehículo guardado correctamente", mensaje);

        String mensajeDuplicado = arregloVehiculo.adicionar(vehiculo);
        assertEquals("El vehículo ya existe", mensajeDuplicado);
    }

    @Test
    public void testBuscarVehiculo() {
        ArregloVehiculo arregloVehiculo = new ArregloVehiculo();
        Vehiculo vehiculo = new Vehiculo(2, "Honda", "Civic", "XYZ-789", "Automática", "Diesel", 4, "Lujo", 70.0, "Disponible", "ruta/honda.png");
        arregloVehiculo.adicionar(vehiculo);

        Vehiculo encontrado = arregloVehiculo.buscar(2);
        assertNotNull(encontrado);
        assertEquals("Honda", encontrado.getMarca());
    }

    @Test
    public void testEliminarVehiculo() {
        ArregloVehiculo arregloVehiculo = new ArregloVehiculo();
        Vehiculo vehiculo = new Vehiculo(3, "Ford", "Focus", "DEF-456", "Manual", "Gasolina", 4, "Económico", 55.0, "Alquilado", "ruta/ford.png");
        arregloVehiculo.adicionar(vehiculo);

        arregloVehiculo.eliminar(vehiculo);
        assertNull(arregloVehiculo.buscar(3));
    }

    @Test
    public void testActualizarVehiculo() {
        ArregloVehiculo arregloVehiculo = new ArregloVehiculo();
        Vehiculo vehiculo = new Vehiculo(4, "Nissan", "Sentra", "GHI-789", "Automática", "Gasolina", 5, "Lujo", 75.0, "Disponible", "ruta/nissan.png");
        arregloVehiculo.adicionar(vehiculo);

        Vehiculo vehiculoActualizado = new Vehiculo(4, "Nissan", "Sentra", "GHI-789", "Automática", "Híbrido", 5, "Lujo", 80.0, "Disponible", "ruta/nissan_actualizado.png");
        arregloVehiculo.actualizar(vehiculoActualizado);

        Vehiculo encontrado = arregloVehiculo.buscar(4);
        assertNotNull(encontrado);
        assertEquals("Híbrido", encontrado.getCombustible());
        assertEquals(80.0, encontrado.getCosto());
    }

    @Test
    public void testObtMarca() {
        ArregloVehiculo arregloVehiculo = new ArregloVehiculo();
        Vehiculo vehiculo1 = new Vehiculo(5, "Toyota", "Yaris", "JKL-123", "Manual", "Gasolina", 5, "Económico", 40.0, "Disponible", "ruta/toyota_yaris.png");
        Vehiculo vehiculo2 = new Vehiculo(6, "Toyota", "RAV4", "MNO-456", "Automática", "Gasolina", 7, "SUV", 100.0, "Disponible", "ruta/toyota_rav4.png");
        arregloVehiculo.adicionar(vehiculo1);
        arregloVehiculo.adicionar(vehiculo2);

        ArrayList<Vehiculo> toyotas = arregloVehiculo.obtMarca("Toyota");
        assertEquals(2, toyotas.size());
        assertEquals("Yaris", toyotas.get(0).getModelo());
        assertEquals("RAV4", toyotas.get(1).getModelo());
    }

    @Test
    public void testTotalVehi() {
        ArregloVehiculo arregloVehiculo = new ArregloVehiculo();
        assertEquals(0, arregloVehiculo.totalVehi());

        arregloVehiculo.adicionar(new Vehiculo(7, "Volkswagen", "Jetta", "PQR-789", "Automática", "Gasolina", 5, "Sedán", 65.0, "Disponible", "ruta/vw_jetta.png"));
        assertEquals(1, arregloVehiculo.totalVehi());
    }
}
