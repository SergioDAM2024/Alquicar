package modelo;

import bean.Boleta;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ArregloBoletaTest {

    @Test
    public void testAdicionarBoleta() {
        ArregloBoleta arregloBoleta = new ArregloBoleta();
        Boleta boleta = new Boleta(1, "Juan Perez", "Ana Lopez", "Toyota Corolla", "2025-04-26", "2025-05-01", 150.50);

        String mensaje = arregloBoleta.adicionar(boleta);
        assertEquals("Boleta guardada correctamente", mensaje);

        String mensajeDuplicado = arregloBoleta.adicionar(boleta);
        assertEquals("La boleta ya existe", mensajeDuplicado);
    }

    @Test
    public void testBuscarBoleta() {
        ArregloBoleta arregloBoleta = new ArregloBoleta();
        Boleta boleta = new Boleta(2, "Luis Garcia", "Pedro Fernandez", "Honda Civic", "2025-05-01", "2025-05-05", 200.75);
        arregloBoleta.adicionar(boleta);

        Boleta encontrada = arregloBoleta.buscar(2);
        assertNotNull(encontrada);
        assertEquals("Luis Garcia", encontrada.getEmpleado());
    }

    @Test
    public void testEliminarBoleta() {
        ArregloBoleta arregloBoleta = new ArregloBoleta();
        Boleta boleta = new Boleta(3, "Ana Martinez", "Carlos Perez", "Ford Focus", "2025-05-10", "2025-05-15", 250.0);
        arregloBoleta.adicionar(boleta);

        arregloBoleta.eliminar(boleta);
        assertNull(arregloBoleta.buscar(3));
    }

    @Test
    public void testActualizarBoleta() {
        ArregloBoleta arregloBoleta = new ArregloBoleta();
        Boleta boleta = new Boleta(4, "Mario Fernandez", "Jose Martinez", "Nissan Sentra", "2025-05-20", "2025-05-25", 300.0);
        arregloBoleta.adicionar(boleta);

        Boleta boletaActualizada = new Boleta(4, "Mario Fernandez", "Jose Martinez", "Nissan Sentra", "2025-05-22", "2025-05-27", 320.0);
        arregloBoleta.actualizar(boletaActualizada);

        Boleta encontrada = arregloBoleta.buscar(4);
        assertNotNull(encontrada);
        assertEquals("2025-05-22", encontrada.getFechaInicio());
        assertEquals(320.0, encontrada.getMonto());
    }

    @Test
    public void testTotalCont() {
        ArregloBoleta arregloBoleta = new ArregloBoleta();
        assertEquals(0, arregloBoleta.totalCont());

        arregloBoleta.adicionar(new Boleta(5, "Carmen Lopez", "Miguel Santos", "Volkswagen Jetta", "2025-06-01", "2025-06-07", 350.0));
        assertEquals(1, arregloBoleta.totalCont());
    }
}
