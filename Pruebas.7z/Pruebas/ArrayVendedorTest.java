package modelo;

import bean.Vendedor;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class ArrayVendedorTest {

    @Test
    public void testAgregarVendedor() {
        ArrayVendedor arrayVendedor = new ArrayVendedor();
        Vendedor vendedor = new Vendedor(1, "Carlos", "Perez", "Lopez", 30, "123456789", "M");

        String resultado = arrayVendedor.agregar(vendedor);
        assertEquals("Vendedor guardado correctamente", resultado);

        String resultadoDuplicado = arrayVendedor.agregar(vendedor);
        assertEquals("El vendedor ya existe", resultadoDuplicado);
    }

    @Test
    public void testBuscarVendedor() {
        ArrayVendedor arrayVendedor = new ArrayVendedor();
        Vendedor vendedor = new Vendedor(2, "Luis", "Garcia", "Ramirez", 25, "987654321", "M");
        arrayVendedor.agregar(vendedor);

        Vendedor encontrado = arrayVendedor.buscar(2);
        assertNotNull(encontrado);
        assertEquals("Luis", encontrado.getNombreVendedor());
    }

    @Test
    public void testEliminarVendedor() {
        ArrayVendedor arrayVendedor = new ArrayVendedor();
        Vendedor vendedor = new Vendedor(3, "Ana", "Martinez", "Gomez", 28, "543216789", "F");
        arrayVendedor.agregar(vendedor);

        arrayVendedor.eliminar(vendedor);
        assertNull(arrayVendedor.buscar(3));
    }

    @Test
    public void testActualizarVendedor() {
        ArrayVendedor arrayVendedor = new ArrayVendedor();
        Vendedor vendedor = new Vendedor(4, "Mario", "Fernandez", "Santos", 35, "789654321", "M");
        arrayVendedor.agregar(vendedor);

        Vendedor vendedorActualizado = new Vendedor(4, "Mario", "Fernandez", "Lopez", 36, "789654321", "M");
        arrayVendedor.actualizar(vendedorActualizado);

        Vendedor encontrado = arrayVendedor.buscar(4);
        assertNotNull(encontrado);
        assertEquals("Lopez", encontrado.getApeMatVendedor());
        assertEquals(36, encontrado.getEdad());
    }

    @Test
    public void testCantidadVendedor() {
        ArrayVendedor arrayVendedor = new ArrayVendedor();
        assertEquals(0, arrayVendedor.cantidadVendedor());

        arrayVendedor.agregar(new Vendedor(5, "Jose", "Hernandez", "Diaz", 40, "654789321", "M"));
        assertEquals(1, arrayVendedor.cantidadVendedor());
    }
}
