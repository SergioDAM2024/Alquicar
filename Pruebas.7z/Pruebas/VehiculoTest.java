package bean;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VehiculoTest {

    @Test
    public void testConstructorCompleto() {
        Vehiculo vehiculo = new Vehiculo(1, "Toyota", "Corolla", "ABC-123", "Manual", "Gasolina", 5, "Económico", 50.0, "Disponible", "ruta/img.png");

        assertEquals(1, vehiculo.getCodigo());
        assertEquals("Toyota", vehiculo.getMarca());
        assertEquals("Corolla", vehiculo.getModelo());
        assertEquals("ABC-123", vehiculo.getPlaca());
        assertEquals("Manual", vehiculo.getTransmision());
        assertEquals("Gasolina", vehiculo.getCombustible());
        assertEquals(5, vehiculo.getAsientos());
        assertEquals("Económico", vehiculo.getCategoria());
        assertEquals(50.0, vehiculo.getCosto());
        assertEquals("Disponible", vehiculo.getEstado());
        assertEquals("ruta/img.png", vehiculo.getRutaImg());
    }

    @Test
    public void testConstructorSimple() {
        Vehiculo vehiculo = new Vehiculo(2, "Honda", "Civic", "XYZ-789");

        assertEquals(2, vehiculo.getCodigo());
        assertEquals("Honda", vehiculo.getMarca());
        assertEquals("Civic", vehiculo.getModelo());
        assertEquals("XYZ-789", vehiculo.getPlaca());
    }

    @Test
    public void testSettersAndGetters() {
        Vehiculo vehiculo = new Vehiculo(0, "", "", "", "", "", 0, "", 0.0, "", "");

        vehiculo.setCodigo(3);
        vehiculo.setMarca("Ford");
        vehiculo.setModelo("Focus");
        vehiculo.setPlaca("DEF-456");
        vehiculo.setTransmision("Automática");
        vehiculo.setCombustible("Diésel");
        vehiculo.setAsientos(4);
        vehiculo.setCategoria("Lujo");
        vehiculo.setCosto(70.5);
        vehiculo.setEstado("Alquilado");
        vehiculo.setRutaImg("imagen/foto.png");

        assertEquals(3, vehiculo.getCodigo());
        assertEquals("Ford", vehiculo.getMarca());
        assertEquals("Focus", vehiculo.getModelo());
        assertEquals("DEF-456", vehiculo.getPlaca());
        assertEquals("Automática", vehiculo.getTransmision());
        assertEquals("Diésel", vehiculo.getCombustible());
        assertEquals(4, vehiculo.getAsientos());
        assertEquals("Lujo", vehiculo.getCategoria());
        assertEquals(70.5, vehiculo.getCosto());
        assertEquals("Alquilado", vehiculo.getEstado());
        assertEquals("imagen/foto.png", vehiculo.getRutaImg());
    }
}
