package bean;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BoletaTest {

    @Test
    public void testConstructor() {
        Boleta boleta = new Boleta(1, "Juan Perez", "Pedro Lopez", "Toyota Corolla", "2025-04-26", "2025-05-01", 150.50);

        assertEquals(1, boleta.getCodigo());
        assertEquals("Juan Perez", boleta.getEmpleado());
        assertEquals("Pedro Lopez", boleta.getCliente());
        assertEquals("Toyota Corolla", boleta.getVehiculo());
        assertEquals("2025-04-26", boleta.getFechaInicio());
        assertEquals("2025-05-01", boleta.getFechaFinal());
        assertEquals(150.50, boleta.getMonto());
    }

    @Test
    public void testSettersAndGetters() {
        Boleta boleta = new Boleta(0, "", "", "", "", "", 0.0);

        boleta.setCodigo(2);
        boleta.setEmpleado("Ana Garcia");
        boleta.setCliente("Luis Martinez");
        boleta.setVehiculo("Honda Civic");
        boleta.setFechaInicio("2025-05-01");
        boleta.setFechaFinal("2025-05-10");
        boleta.setMonto(200.75);

        assertEquals(2, boleta.getCodigo());
        assertEquals("Ana Garcia", boleta.getEmpleado());
        assertEquals("Luis Martinez", boleta.getCliente());
        assertEquals("Honda Civic", boleta.getVehiculo());
        assertEquals("2025-05-01", boleta.getFechaInicio());
        assertEquals("2025-05-10", boleta.getFechaFinal());
        assertEquals(200.75, boleta.getMonto());
    }
}
